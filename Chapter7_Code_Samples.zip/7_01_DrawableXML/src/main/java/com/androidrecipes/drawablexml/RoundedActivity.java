package com.androidrecipes.drawablexml;

import android.app.Activity;
import android.os.Bundle;

public class RoundedActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rounded);
    }
}