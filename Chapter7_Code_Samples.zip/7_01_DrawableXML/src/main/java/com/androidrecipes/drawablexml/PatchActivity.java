package com.androidrecipes.drawablexml;

import android.app.Activity;
import android.os.Bundle;

public class PatchActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.patch);
    }
}