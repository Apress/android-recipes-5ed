# Android Recipes Source Code #

Example source code for all chapters in Android Recipes.

It is recommended that you edit `settings.gradle` and only include the projects you want to test. You can easily change this from Android Studio and performa Gradle resync to update the IDE.