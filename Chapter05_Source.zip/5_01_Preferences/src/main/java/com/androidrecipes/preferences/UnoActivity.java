package com.androidrecipes.preferences;

import android.app.Activity;
import android.os.Bundle;

public class UnoActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
